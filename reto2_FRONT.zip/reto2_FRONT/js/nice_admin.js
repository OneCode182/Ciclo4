
window.onload = () => {
    dialogLogin();

}

function dialogLogin() {
    dialog(false, "¡ INCIO DE SESIÓN EXITOSO !");
}

function dialog(error, body) {
    let title = "";
    $("#myToast").removeClass();
    if (error) {
        title += "¡ERROR!";
        $("#myToast").addClass("toast bg-danger")
        
    } else {
        title += "INFO";
        $("#myToast").addClass("toast bg-primary")

    } document.getElementById("titulomensaje").innerHTML = title;
    $("#cuerpomensaje").html(body);
    $("#myToast").toast("show");
}
