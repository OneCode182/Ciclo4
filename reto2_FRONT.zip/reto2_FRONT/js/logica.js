
/*const URL_BASE = { // URL PARA VM (MAQUINA VIRTUAL EN ORACLE CLOUD)
    "host" : "http://<IP>:8080/api/"

};*/

const URL_BASE = { // URL PARA ENTORNO LOCAL (LOCALHOST 127.0.0.1)
    "host" : "http://localhost:8080/api/"
};

function URL_GET_EMAIL(email) {
    return URL_BASE.host + "user/emailexist/" + email;
}


const crear = () => {
    //document.getElementById('txtNombre').value;
    const name = $('#txtNombre').val();
    const email = $('#txtMail').val();
    const password = $('#txtClave').val();
    const confirmar = $('#txtConfirmarClave').val(); 
    
    // validaciones
    if(name.length==0 || email.length==0) {
        mostrarMensaje('Error', 'Todos los campos son obligatorios', true);
        $("#loading").html("");
        return;
    }else if(email.charAt(0) == "." || email.charAt(email.length - 1) == "." ){
        mostrarMensaje('Error', 'El Email no debe empezar ni terminar por puntos', true);
        return;

    } else if (!emailDomain(email)) { // Estuctura de email basica email@dominio.sub

        mostrarMensaje('Error', 'El Email debe tener la estructura email@dominio.sub', true);
        return;

    } else if (password !== confirmar) {
        mostrarMensaje('Error', 'Las claves no coinciden', true);
        return;
    } else if (password.length < 6) {
        mostrarMensaje('Error', 'La clave debe tener minimo 6 caracteres', true);
        return;
    }
    
     //objeto enviado al servidor
    const payload = {
        email: email,
        password: password,
        name: name
        
    };

    $.ajax({
        url: `${urlbase}/new`,
        type: "POST",
        dataType: 'json',
        headers: {
            "Content-Type": "application/json"
        },
        data: JSON.stringify(payload),
        statusCode: {
            201: function () {
                mostrarMensaje('Listo', 'Usuario Creado');
                //alert('Usuario Creado');
            }
        },
    });

}



//mensajes de aprobacion o error
const mostrarMensaje = (titulo, cuerpo, error) => {
    document.getElementById("titulomensaje").innerHTML = titulo;//tradicional
    $("#cuerpomensaje").html(cuerpo);//query igual al tradicional
    $("#myToast").removeClass();
    if (error) {
        $("#myToast").addClass("toast bg-danger")
    } else {
        $("#myToast").addClass("toast bg-primary")
    }

    $("#myToast").toast("show");
}
//
function checkCaracter(string, character) { // @
    for (let i = 0; i < string.length; i++) { //email@sadfsdf
        let char = string.charAt(i);
        if (char == character) {
            return true;
        }


    } return false;
}
//reconoce el dominio
function getDomain(email) {
    for (let i = 0; i < email.length; i++) {
        let char = email.charAt(i);
        if (char == "@") { //email@dsf.sdfsdf
            return email.slice(i + 1, email.length - 1);
        }

    } return "";
}

function emailDomain(email) {
    // verificar existencia de '@'
    if (!checkCaracter(email, "@")) { // 
        return false;

    } else if (email.charAt(email.length - 1) == "@") {
        return false;

    } else { // email@dsf.sdfsdf
        let dominio = getDomain(email);
        if (dominio.charAt(0) == "." || dominio.charAt(dominio.length - 1) == "." ) {
            return false;

        } else if (!checkCaracter(dominio, ".")) {
            return false;
        }

    } return true

}


//inicio de sesion
const iniciarSesion = () => {
    const loading = '<img src="img/spinner.gif">';
    $("#loading").html(loading);
    //ejecucion solo para local
    setTimeout(()=>{
        autenticar();
    }, 1000);
}

const autenticar = ()=>{
    const email = $("#txtMail").val();
    const password = $("#txtClave").val();

    if (email.length === 0 || password.length === 0) {
        mostrarMensaje('Error', 'Debe escribir el correo y la clave para ingresar', true);
        $("#loading").html("");
        return;
    }

    $.ajax({
        url: `${urlbase}/${email}/${password}`,
        type: 'GET',
        dataType: 'json',
        success: function (respuesta) {
            $("#loading").html("");
            console.log(respuesta);
            if (respuesta.id===null){
                mostrarMensaje('Error', 'Usuario y/o clave incorrectos', true);
            }else{
                mostrarMensaje('Autorizado', 'Ingreso Correcto');

                setTimeout(()=>{
                    window.location.href = 'menu.html';
                }, 1000);
                
            }
        },
        error: function (xhr, status) {
            $("#loading").html("");
            console.log(xhr);
            console.log(status);
            mostrarMensaje('Error', 'Error al validar', true);
        }
    });



}
