
const hosting = false; // true 'localhost' | false 'virtual machine'

const ip_local = "localhost";
const port_local = "8080";

const ip_server = "129.151.122.91";
const port_server = "8080";



function URL_BASE() {
    const protocol = "http://";
    const base_api = "/api/";

    if (hosting) {
        return protocol + ip_local + ":" + port_local + base_api;

    } return protocol + ip_server + ":" + port_server + base_api;
};

function URL_GET_EMAIL(email) {
    return URL_BASE() + "user/emailexist/" + email;
}

function URL_GET_USER(email, password) {
    return URL_BASE() + "user/" + email + "/" + password;
}


function getInputs() {
    return compactStringArray([
        $("#input_email").val(),
        $("#input_password").val()
    ]);
    
}

function getPassword() {
    return $("#input_password").val();
    
}

function compactStringArray(array) {
    let data = []; for (let i = 0; i < array.length; i++) {
        data.push(array[i].trim());

    } return data;

}


function printArray(array) {
    let data = "";
    for (let i = 0; i < array.length; i++) {
        data += "DATA " + (i + 1) + " >> " + array[i] + "\n";

    } console.log(data);

}

function dialogNICE() {
    dialog(false, "¡ NICE !");
}



function errorPassword() {
    dialog(true, "La contraseña es incorrecta !");
}

function errorEmptyInputs() {
    dialog(true, "Todos los campos son obligatorios");
}

function errorPointSides() {
    dialog(true, "El email no debe contener '.' al inicio, ni al final");
}

function errorGET() {
    dialog(true, "Hubo un error en la petición GET !");
}

function errorUserLikeADM() {
    dialog(true, "El usuario ingresado es Administrador !");
}

function errorLoginEmail() {
    dialog(true, "El email ingresado no está registrado !");
}

function errorEmailDomain() {
    dialog(true, "El email no cumple con la" +
        "\nestructura de Email@dominio.subdominio !"
    );
}

function checkBegin_End(string, character) {
    for (let i = 0; i < string.length; i++) {
        if (string[0] == character || string.substr(-1) == character) {
            return false;
        }

    } return true;

}

// Verificar un caracter en un string
function checkCaracter(string, character) { // @
    for (let i = 0; i < string.length; i++) { //email@sadfsdf
        let char = string.charAt(i);
        if (char == character) {
            return true;
        }


    } return false;
}

// Extraer el dominio '@dominio.subdominio'
function getDomain(email) {
    for (let i = 0; i < email.length; i++) {
        let char = email.charAt(i);
        if (char == "@") {
            return email.slice(i + 1, email.length);
        }

    } return "";
}

function emailDomain(email) {
    const at = "@";
    let point = ".";
    if (!checkCaracter(email, at)) { // Verificar existencia de '@'
        return false;

    } else if (email[0] == at || email.substr(-1) == at) { // Que no comience ni termine con '@'
        return false;

    } else { // Estructura de Email@dominio.subdominio
        let dominio = getDomain(email);
        if (!checkCaracter(dominio, point)) {
            return false;

        } else if (dominio.charAt(0) == point) { 
            return false;
            
        }

    } return true; // email@gmail.com

}


function apiGET() {


}



function checkLogin() {
    const data = getInputs();
    //printArray(data);
    
    if (emptyInputs(data)) {
        errorEmptyInputs();

    } else if (!checkBegin_End(data[0], ".")) {
        errorPointSides();

    } else if (!emailDomain(data[0])) {
        errorEmailDomain();

    } else {
        //dialogNICE();
        let URL = URL_GET_EMAIL(data[0]);

        jqueryGET(URL, jqueryGETEmail);

    }
    
}

const jqueryGETUser = (respuesta) => {
    if(respuesta.id == null) {
        errorPassword();

    } else if (respuesta.type == "ADM") {
        errorUserLikeADM();

    } else {
        window.location.href = "nice_user.html";
        //dialogLogin();

    }

}

const jqueryGETEmail = (exists) => {
    if (!exists) {
        errorLoginEmail();

    } else {
        const data = getInputs();
        const URL = URL_GET_USER(data[0], data[1]);

        jqueryGET(URL, jqueryGETUser);

    }

}


function jqueryGET(url, def) {
    $.ajax({
        url: url,
        type: "GET",
        dataType: "JSON",
        success: function (respuesta) {
            $("#loading").html("");
            //console.log(JSON.stringify(respuesta));
            def(respuesta);

        }, error: function (xhr, status) {
            $("#loading").html("");
            console.log(xhr);
            console.log(status);
            errorGET();
        }

    });

}


function emptyInputs(inputs) {
    for (let i = 0; i < inputs.length; i++) {
        let string = inputs[i];
        if (string.length == 0) {
            return true;

        } else {
            for (let j = 0; j < string.length; j++) {
                let character = string.charAt(j);
                if (character == " ") {
                    return true;
                }
            }
        }

    } return false;
}



function dialog(error, body) {
    let title = "";
    $("#myToast").removeClass();
    if (error) {
        title += "¡ERROR!";
        $("#myToast").addClass("toast bg-danger")
        
    } else {
        title += "INFO";
        $("#myToast").addClass("toast bg-primary")

    } document.getElementById("titulomensaje").innerHTML = title;
    $("#cuerpomensaje").html(body);
    $("#myToast").toast("show");
}
