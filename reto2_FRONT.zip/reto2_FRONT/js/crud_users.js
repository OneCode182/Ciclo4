

let hosting = false; // true 'localhost' | false 'virtual machine'

let protocol = "http://";
let base_api = "/api/";

let ip_local = "localhost";
let port_local = 8080;

let ip_server = "129.151.122.91";
let port_server = 5500;




function URL_BASE() {
    if (hosting) {
        return protocol + ip_local + ":" + port_local + base_api;

    } else {
        return protocol + ip_server + ":" + port_server + base_api;
    }
};

function URL_GET_EMAIL(email) {
    return URL_BASE() + "user/emailexist/" + email;
}

function URL_GET_USER(email, password) {
    return URL_BASE() + "user/" + email + "/" + password;
}

function URL_USERS() {
    return URL_BASE() + "user/all";
}

function URL_DELETE(id) {
    return URL_BASE() + "user/" + id;
}

function URL_PUT() {
    return URL_BASE() + "user/update";
}

window.onload = function() {
    jqueryGET(URL_USERS(), buildTable);

}

function errorEmptyInputs() {
    dialog(true, "Todos los campos son obligatorios", true);
}

function errorNameNumber() {
    dialog(true, "El nombre de usuario es incorrecto", true);
}

function errorIDNotNumber() {
    dialog(true, "El nombre de usuario es incorrecto", true);
}

function getHeader() {
    return "<table class='table'>" +
    "<thead class='p-3 mb-2 bg-dark text-white'>" +
    "<th>IDENTIFICACIÓN</th> " +
    "<th>NOMBRE</th>" +
    "<th>DIRECCIÓN</th>" +
    "<th>CELULAR</th>" +
    "<th>EMAIL</th>" +
    "<th>CONTRASEÑA</th>" +
    "<th>ZONA</th>" +
    "<th>TIPO</th>" +
    "<th>ACCIONES</th>" +
    "</thead>" +
    "<tbody>";

}

function jqueryPUT(url, def) {

}

function jqueryDEL(url, def) {

}

function inputsUpdate(id ,identification) {
    let data = [
        $("#userIdentification").val(),
        $("#userName").val(),
        $("#userAddress").val(),
        $("#userPhone").val(),
        $("#userEmail").val(),
        $("#userPassword").val(),
        $("#userZone").val(),
        $("#userType").val()
    ]

    $("#userIdentification" + id).replaceWith("<td <input type='text' id='userIdentification" + id + " value='" + identification + "'></td>");
    
}

function printArray(array) {
    let data = "";
    for (let i = 0; i < array.length; i++) {
        data += "DATA " + (i + 1) + " >> " + array[i] + "\n";

    } console.log(data);

}

function resetInputsNew() {
    return [
        $("#new_username").val(""),
        $("#new_doc").val(""),
        $("#new_phone").val(""),
        $("#new_address").val(""),
        $("#new_email").val(""),
        $("#new_password").val(""),
        $("#new_zone").val("1"),
        $("#new_type").val("Coordinador de zona")
    ];

}

function getInputsNew() {
    return [
        $("#new_username").val(),
        $("#new_doc").val(),
        $("#new_phone").val(),
        $("#new_address").val(),
        $("#new_email").val(),
        $("#new_password").val(),
        $("#new_zone").val(),
        $("#new_type").val()
    ];

}

function checkNewUser() {
    let data = getInputsNew();
    //printArray(data);

    if (emptyInputs(data)) {
        errorEmptyInputs();

    } else if (!isNaN(data[0])) {
        errorNameNumber();

    } else if (isNaN(data[1])) {
        errorNameNumber();

    }

}


function emptyInputs(inputs) {
    for (let i = 0; i < inputs.length; i++) {
        let string = inputs[i];
        if (string.length == 0) {
            return true;

        } else {
            for (let j = 0; j < string.length; j++) {
                let character = string.charAt(j);
                if (character == " ") {
                    return true;
                }
            }
        }

    } return false;
}



let buildTable = function(data) {
    $("#table").empty();
    let table = getHeader();
    //let URL_PUT = URL_PUT();

    for (let i = 0; i < data.length; i++) {
        
        let URL_DEL = URL_DELETE(data[i].id);
        let TYPE = "";
        let BTN_DEL_ID = "";
        if (data[i].type == "ADM") {
            TYPE += "Administrador";
            BTN_DEL_ID += "btn_delete";

        } else if (data[i].type == "COORD") {
            TYPE += "Coordinador de zona";

        } else if (data[i].type == "ASE") {
            TYPE += "Asesor comercial";

        }
        
        
        table += "<tr>" +
        "<td id='userIdentification" + data[i].id + "'>" + data[i].identification + "</td>" +
        "<td id='userName" + data[i].id + "'>" + data[i].name + "</td>" +
        "<td id='userAddress" + data[i].id + "'>" + data[i].address + "</td>" +
        "<td id='userPhone" + data[i].id + "'>" + data[i].cellPhone + "</td>" +
        "<td id='userEmail" + data[i].id + "'>" + data[i].email + "</td>" +
        "<td id='userPassword" + data[i].id + "'>" + data[i].password + "</td>" +
        "<td id='userZone" + data[i].id + "'>" + data[i].zone.substr(-1) + "</td>" +
        "<td id='userType" + data[i].id + "'>" + TYPE + "</td>" +
        "<td> <div align='center'> <button onclick='inputsUpdate(" + data[i].id + ", " + data[i].identification + ")' id='userUpdate" + data[i].id + "' class='btn btn-primary'> Actualizar </button>" +
        "<br><button onclick='jqueryDEL(" + data[i].id + ")' id='" + BTN_DEL_ID + "' class='btn btn-danger' > -Eliminar- </button> </td>" +
        "</div>" +
        "</tr>";

    }

    table += "</tbody> </table>";
    $("#table").append(table);
    //document.getElementById("btn_delete").disabled = true;
    

}

const updateUser = () => {
    alert("Se va a actualizar");

}



function jqueryDEL(id) {
    $.ajax({
        url: URL_DELETE(id),
        type: "DELETE",
        //contentType: "application/JSON",
        //datatype: "JSON",
        success: function (respuesta) {
            //$("#loading").html("");
            dialogDELETE();
            jqueryGET(URL_USERS(), buildTable);
        }
    });
}


function jqueryGET(url, def) {
    $.ajax({
        url: url,
        type: "GET",
        dataType: "JSON",
        success: function (respuesta) {
            //$("#loading").html("");
            //console.log(JSON.stringify(respuesta));
            def(respuesta);

        }, error: function (xhr, status) {
            //$("#loading").html("");
            console.log(xhr);
            console.log(status);
            //errorGET();
        }

    });

}

function dialogDELETE() {
    dialog(false, "¡Se ha eliminado correctamente!");
}

function dialog(error, body, modal) {
    let title = "";
    let modal_class = "#myToast";
    let title_class = "#titulomensaje";
    let body_class = "#cuerpomensaje";

    if (modal) {
        modal_class += "2";
        title_class += "2";
        body_class += "2";
    }
    $(modal_class).removeClass();
    if (error) {
        title += "¡ERROR!";
        $(modal_class).addClass("toast bg-danger")
        
    } else {
        title += "INFO";
        $(modal_class).addClass("toast bg-primary")

    } 
    //document.getElementById(title_class).innerHTML = title;
    $(title_class).html(title);
    $(body_class).html(body);
    $(modal_class).toast("show");
}

